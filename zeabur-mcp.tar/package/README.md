# Zeabur MCP Server

A Model Context Protocol (MCP) server for Zeabur, built with TypeScript using [`@zeabur/ai-sdk`](https://www.npmjs.com/package/@zeabur/ai-sdk).

## Installation

### From npm

```bash
npm install -g @zeabur/mcp-server
```

### From source

```bash
git clone https://github.com/zeabur/mcp-server.git
cd mcp-server
npm install
npm run build
```

## Setup

Get your API token from the [API keys](https://dash.zeabur.com/account/api-keys) page.

### Claude Code

```bash
claude mcp add zeabur -e ZEABUR_TOKEN="<YOUR_TOKEN>" -- npx @zeabur/mcp-server
```

Or if installed from source:

```bash
claude mcp add zeabur -e ZEABUR_TOKEN="<YOUR_TOKEN>" -- node /path/to/mcp-server/dist/index.js
```

### Claude Desktop

Open Settings > Edit Config, then add:

```json
{
  "mcpServers": {
    "zeabur": {
      "command": "npx",
      "args": ["@zeabur/mcp-server"],
      "env": {
        "ZEABUR_TOKEN": "<YOUR_TOKEN>"
      }
    }
  }
}
```

![Claude Desktop Settings](docs/claude-settings.png)

### Cursor

Open `~/.cursor/mcp.json` and add:

```json
{
  "mcpServers": {
    "zeabur": {
      "command": "npx",
      "args": ["@zeabur/mcp-server"],
      "env": {
        "ZEABUR_TOKEN": "<YOUR_TOKEN>"
      }
    }
  }
}
```

## Available Tools

All tools are provided by [`@zeabur/ai-sdk`](https://www.npmjs.com/package/@zeabur/ai-sdk).

### Core

| Tool | Description |
|------|-------------|
| `execute-command` | Execute any command on a prebuilt service |
| `deploy-from-specification` | Deploy a project from service specification |

### Projects

| Tool | Description |
|------|-------------|
| `list-projects` | List all projects for the current user |
| `create-project` | Create a new project |

### Regions

| Tool | Description |
|------|-------------|
| `list-regions` | List available regions and optionally dedicated servers |

### Services

| Tool | Description |
|------|-------------|
| `list-services` | List all services in a project |
| `get-service` | Get details of a specific service including domains and dockerfile |
| `create-service` | Create a new service in a project |

### Ports

| Tool | Description |
|------|-------------|
| `update-service-ports` | Update the exposed ports of a service |

### Domains

| Tool | Description |
|------|-------------|
| `add-domain` | Add a domain to a service |

### Templates

| Tool | Description |
|------|-------------|
| `search-template` | Search for deployment templates |
| `deploy-template` | Deploy a template to a project |

### User

| Tool | Description |
|------|-------------|
| `get-me` | Get the current user's information |

### Git

| Tool | Description |
|------|-------------|
| `get-repo-id` | Get the repo ID from a GitHub URL |
| `search-git-repos` | Search for Git repositories |

### Logs & Deployments

| Tool | Description |
|------|-------------|
| `get-build-logs` | Get build logs for a specific deployment |
| `get-runtime-logs` | Get runtime logs for a specific service |
| `get-deployments` | Get deployments for a specific service |

### Filesystem

| Tool | Description |
|------|-------------|
| `decide-filesystem` | Decide which filesystem to use (GitHub or Upload) |
| `list-files` | List files in the filesystem |
| `read-file` | Read content of a file in the filesystem |
| `file-dir-read` | Execute safe read-only commands on a service |

## Development

```bash
# Install dependencies
npm install

# Development mode
npm run dev

# Build
npm run build

# Run
ZEABUR_TOKEN=<YOUR_TOKEN> npm start
```

## License

MIT
